<?php



class Logs extends Model {

	function __construct() {
		parent::__construct('logs');
	}


}
<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Seller List</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Seller List</li>
							</ol>
						</div>
					</div>

    <!-- Main content -->
    <section class="content">
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
   
      <div class="row">
        <div class="col-md-8">
          <div class="card card-box">
		<div class="card-head">
                <header><a href="<?php echo $URI; ?>/add" class="btn btn-warning"><i class="fa fa-plus"></i>Add</a> Seller List</header>
			  
            </div>
            <!-- /.box-header -->    
          
            <div class="card-body table-responsive">
              <table id="fornesia" class="table table-bordered table-hover">
                <thead>
                <tr>
                                        <th>St</th>
                                    	<th>Username</th>
                                    	<th>Balance</th>
                                    	<th>Action</th>
                                    	<th>Email</th>                
                </tr>
                </thead>
                <tbody>
                                <?php $no=0; foreach (($sellers?:array()) as $seller): $no++; ?>
                                     <tr>
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $seller->username; ?></td>                                    
                                        <td><?php echo $seller->saldo; ?></td>
                                        <td> 
     <a href="/home/admin/seller/<?php echo $seller->id; ?>" class="btn btn-primary">Edit</a>&nbsp;
                                            <?php if ($seller->active==1): ?>
                                                
<a href="/home/admin/seller/<?php echo $seller->id; ?>/active/0" class="btn btn-warning">Lock</a>
                                                
                                                <?php else: ?>
<a href="/home/admin/seller/<?php echo $seller->id; ?>/active/1" class="btn btn-success">Unlock</a>
                                                
                                            <?php endif; ?>
                                        </td>                                       
                                     <td><?php echo $seller->email; ?></td> 
                                    </tr>
                                <?php endforeach; ?>                                
                 <tfoot>
                <tr>
                                        <th>St</th>
                                    	<th>Username</th>
                                    	<th>Balance</th>
                                    	<th>Action</th>
                                        <th>Email</th>
                </tr>
                </tfoot>
              </table>               
             </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

    
              <div class="col-md-4">		  
         <div class="card card-box">
		<div class="card-head">
                <header><i class="fa fa-money fa-fw"></i> Quick Deposit</header>
            </div>
            <!-- /.box-header -->
         
            <form role="form" action="/home/admin/seller/deposit" method="POST">
              <div class="card-body">
                       <div class="form-group">
                            <label>Seller</label>
                            <select class="form-control" name="id">
                                <?php foreach (($sellers?:array()) as $seller): ?>
                                    <option value="<?php echo $seller->id; ?>"><?php echo $seller->username; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Deposit</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="100" name="deposit" type="number" min="1" step="1" required>
                            </div>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="form-group">
                <center><button type="submit" class="btn btn-primary">Save</button>
                <button type="reset" class="btn btn-danger">Reset</button></center>                        
              </div>
              
            </form>
          </div>
          <!-- /.box -->
  </div>

</div>    
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
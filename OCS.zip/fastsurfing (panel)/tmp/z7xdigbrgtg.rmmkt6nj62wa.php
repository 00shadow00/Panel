<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
							<?php if ($user->uid): ?>
  							
								<div class="page-title">Edit User</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/home/admin/server">List Server</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Edit User</li>
							</ol>
							
							<?php else: ?>
							<div class="page-title">Add User</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/home/admin/server">List Server</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add User</li>
							</ol>
							
							<?php endif; ?>
						</div>
						</div>


    <!-- Main content -->
    <section class="content"> 
    
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
    
		<div class="row">
        <div class="col-md-6">	
		 <div class="card card-box">
		 <div class="card-head">
               <header><i class="fa fa-user fa-fw"></i> Account Details </header>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="card-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="user" type="text" value="<?php echo $user->user; ?>" required>
                        </div>
                        <?php if (!$user->uid): ?>
                            <div class="form-group">
                                <label>Password</label>
                      <input class="form-control" placeholder="New Password" name="pass" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                      <input class="form-control" placeholder="Re-enter Password" name="pass_confirmation" type="password" required>
                            </div>
                        <?php endif; ?>
              <div class="form-group">
                <label>Exp</label>

                <div class="input-group date">
                <input type="text" class="form-control pull-right datepicker" id="datepicker" name="exp" value="<?php echo $user->exp?$user->exp:date("Y/m/d",strtotime("+31 days")); ?>">
                </div>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
						
              </div>
              <!-- /.box-body -->

              <div class="form-group">
                <center><button type="submit" class="btn btn-primary">Save</button>
                        <?php if ($user->uid): ?>
                            
                                <?php if ($user->lock): ?>
                                    
                                        <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlock</a>
                                    
                                    <?php else: ?>
                                        <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Lock</a>
                                    
                                <?php endif; ?>
                                <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                            
                            <?php else: ?>
                                <a href="/home/admin/server/<?php echo $server->id; ?>/account/" class="btn btn-default">Back</a><center>
                            
                        <?php endif; ?>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>		  
       
        <?php if ($user->uid): ?>		  
        <div class="col-md-6">		  
         <div class="card card-box">
		 <div class="card-head">
               <header><i class="fa fa-cog fa-spin"></i> Change Password</h3></header>

            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="card-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="form-group text-center">
                <button type="submit" class="btn btn-primary">Save</button>
     <a href="/home/admin/server/<?php echo $server->id; ?>/account/" class="btn btn-default"></i> Back</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
<?php endif; ?>
		  
          </div>		  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  
  <script>
      
      
      $('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});
  </script>
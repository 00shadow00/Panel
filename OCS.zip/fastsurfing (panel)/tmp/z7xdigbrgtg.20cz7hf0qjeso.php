<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
							<h1>
		    					<?php if ($server->id): ?>
                    					
                        				<?php echo $server->servername; ?>
                    					
                    					<?php else: ?>
							<div class="page-title">Add Server</div>
							
                					<?php endif; ?>
		    					</h1>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
							<?php if ($server->id): ?>
                    					
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/home/admin/server">List server</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Edit Server <?php echo $server->servername; ?></li>
								
                    						<?php else: ?>
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/home/admin/server">List server</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add Server</li>
								
               						        <?php endif; ?>
							</ol>
						</div>
					</div>



    <!-- Main content -->
    <section class="content">

				<div class="alert alert-info alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i>&nbsp;Note:</h4>
Please, input correct vps password in label Root Password <br>
If wrong password server with can not be add.
              </div>
 		<div class="row">
        <div class="col-md-12">	
	        <?php if ($message): ?>     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i> <?php echo $message['type']; ?></h4>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
        
		 <div class="card card-box">
		 <div class="card-head">
               <header><i class="fa fa-user fa-fw"></i> Server Settings</header>
            </div>
            <!-- /.box-header -->
            <!-- form start -->   

            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="card-body ">
                        <div class="form-group">
              <label>Server Name</label>
              <input class="form-control" placeholder="Server 01" name="servername" type="text" value="<?php echo $server->servername; ?>" required>
            </div>
            <div class="form-group">
              <label>Server Location</label>
              <input class="form-control" placeholder="Singapore, USA" name="country" type="text" value="<?php echo $server->country; ?>" required>
            </div>
            <div class="form-group">
              <label>IP Address / Hostname</label>
              <input class="form-control" placeholder="128.199.xxx.xx or etc." name="host" type="text" value="<?php echo $server->host; ?>" required>
            </div>
            <div class="form-group">
              <label>SSH Port</label>
              <input class="form-control" placeholder="22" name="openssh" type="text" value="22" required>
            </div>
            <div class="form-group">
              <label>Dropbear Port</label>
              <input class="form-control" placeholder="none kung wala" name="dropbear" type="text" value="442" required>
            </div>
            <div class="form-group">
              <label>SSL Port</label>
              <input class="form-control" placeholder="none kung wala" name="stunnel" type="text" value="443" required>
            </div>
            <div class="form-group">
              <label>OpenVPN Port</label>
              <input class="form-control" placeholder="465" name="openvpn_port" type="openvpn_port" value="1194" required>
            </div>
            <div class="form-group">
              <label>OpenVPN Link</label>
              <input class="form-control" placeholder="your-ip:88/GTMConfig.ovpn or your own link" name="openvpn_link" type="text" value="<?php echo $server->openvpn_link; ?>" required>
            </div>
            <div class="form-group">
              <label>Squid Port</label>
              <input class="form-control" placeholder="8080, 3128, 8000, 80" name="proxy" type="text" value="8118" required>
            </div>
            <div class="form-group">
              <label>Server Owner</label>
              <input class="form-control" name="server_owner" type="text" value="Dark Cry" required>
            </div>
            <div class="form-group">
              <label>Torrent Allow ?</label>
              <select class="form-control" name="torrent" value="<?php echo $server->torrent; ?>">
                <option value="No">No</option>
                <option value="Yes">Yes</option>
              </select>
            </div>
            <!-- <div class="form-group">
              <label>User limit</label>
              <input class="form-control" placeholder="this function is not working, use 0 instead" name="limitacc" type="text" value="<?php echo $server->limitacc; ?>" required>
            </div> -->
            <div class="form-group">
              <label>Account Creation Cost</label>
              <div class="input-group">
                <span class="input-group-addon"></span>
                <input class="form-control" placeholder="1" name="price" type="number" step="1" value="<?php echo $server->price; ?>" required>
              </div>
            </div>
            <div class="form-group">
              <label>Root Password</label>
              <input class="form-control" placeholder="root" name="root_pass" type="password">
            </div>
						
              </div>
              <!-- /.box-body -->

              <div class="form-group">
                <center><button type="submit" class="btn btn-round btn-primary">Save</button>
                       <?php if ($server->id): ?>
                            <?php if ($server->active==1): ?>
                                
                                    <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-round btn-warning">Lock</a>
                                
                                <?php else: ?>
                                    <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-round btn-success">Unlock</a>
                                
                            <?php endif; ?>
                            <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-round btn-danger">Delete</a>
                        <?php endif; ?>
                        <a href="/home/admin/server" class="btn btn-round btn-default">Back</a></center>
              </div>
            
            </form>
          </div>
          <!-- /.box -->
          </div>		           
         
     </div>	     
         
         
         
         
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
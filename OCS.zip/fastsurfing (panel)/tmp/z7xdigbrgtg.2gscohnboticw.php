<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->

<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<meta name="description" content="Responsive Admin Template" />
	<meta name="author" content="SmartUniversity" />
	<title>FastSurfing VPN panel | </title>
	<script language='JavaScript'>
        var txt = '   ' + document.title + '   '
        var speed = 400;
        var refresh = null;
        function site_name() 
		{
            		document.title = txt;
            		txt = txt.substring(1, txt.length) + txt.charAt(0);
            		refresh = setTimeout("site_name()", speed);
        	}
        site_name();     
    	</script>
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css" />
	<!-- icons -->
	<link href="/assets/fonts/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
	<link href="/assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="/assets/fonts/material-design-icons/material-icon.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.9/css/all.css">
	<!--bootstrap -->
	<link href="/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="/assets/plugins/summernote/summernote.css" rel="stylesheet">
	<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
  	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
  	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

	<!-- Material Design Lite CSS -->
	<link rel="stylesheet" href="/assets/plugins/material/material.min.css">
	<link rel="stylesheet" href="/assets/css/material_style.css">
	<!-- inbox style -->
	<link href="/assets/css/pages/inbox.min.css" rel="stylesheet" type="text/css" />
	<!-- Theme Styles -->
	<link href="/assets/css/theme/dark/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
	<link href="/assets/css/plugins.min.css" rel="stylesheet" type="text/css" />
	<link href="/assets/css/theme/dark/style.css" rel="stylesheet" type="text/css" />
	<link href="/assets/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="/assets/css/theme/dark/theme-color.css" rel="stylesheet" type="text/css" />
	
	
	<link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
	
	<!-- favicon -->
	<link rel="shortcut icon" href="http://radixtouch.in/templates/admin/smart/source/assets/img/favicon.ico" />
	<style>
.fa-heart {
  color: #DC3545;
  font-size: 20px;
}

@-webkit-keyframes heartbeat {
  0% {
    -webkit-transform:scale(1)
  }
  50% {
    -webkit-transform:scale(1.4)
  }
  100% {
    -webkit-transform:scale(1)
  }
}

@-moz-keyframes heartbeat {
  0% {
    -moz-transform:scale(1)
  }
  50% {
    -moz-transform:scale(1.4)
  }
  100% {
    -moz-transform:scale(1)
  }
}

@-o-keyframes heartbeat {
  0% {
    -o-transform:scale(1)
  }
  50% {
    -o-transform:scale(1.4)
  }
  100% {
    -o-transform:scale(1)
  }
}

@keyframes heartbeat {
  0% {
    transform: scale(.75);
}
20% {
    transform: scale(1);
}
40% {
    transform: scale(.75);
}
60% {
    transform: scale(1);
}
80% {
    transform: scale(.75);
}
100% {
    transform: scale(.75);
}
}

.heartbeat {
  -webkit-animation-name: heartbeat;
  -moz-animation-name: heartbeat;
  -o-animation-name: heartbeat;
  animation-name: heartbeat;
}

.animate-infinite-heartbeat {
  -webkit-animation: heartbeat s infinite;
  animation: heartbeat 1s infinite;
}
</style>
</head>
<!-- END HEAD -->

<body
	class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-dark dark-sidebar-color logo-dark dark-theme">

    <?php echo $this->render($content,$this->mime,get_defined_vars()); ?>

<!-- start js include path -->
	<script src="/assets/plugins/jquery/jquery.min.js"></script>
	<script src="/assets/plugins/popper/popper.js"></script>
	<script src="/assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
	<script src="/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
	<!-- bootstrap -->
	<script src="/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<script src="/assets/plugins/sparkline/jquery.sparkline.js"></script>
	<script src="/assets/js/pages/sparkline/sparkline-data.js"></script>
	<!-- Common js-->
	<script src="/assets/js/app.js"></script>
	<script src="/assets/js/layout.js"></script>
	<script src="/assets/js/theme-color.js"></script>
	
	<!-- dataTables -->
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
	
	
	
	
	<!-- material -->
	<script src="/assets/plugins/material/material.min.js"></script>
	<!-- chart js -->
	<script src="/assets/plugins/chart-js/Chart.bundle.js"></script>
	<script src="/assets/plugins/chart-js/utils.js"></script>
	<script src="/assets/js/pages/chart/chartjs/home-data.js"></script>
	<!-- summernote -->
	<script src="/assets/plugins/summernote/summernote.js"></script>
	<script src="/assets/js/pages/summernote/summernote-data.js"></script>
	<script>
	// number count for stats, using jQuery animate

$('.counting').each(function() {
  var $this = $(this),
      countTo = $this.attr('data-count');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 3000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  

});


$(document).ready(function() {
    $('#fornesia').DataTable();
} );

</script>
	<!-- end js include path -->
<!-- start footer -->
		<div class="page-footer">
			<div class="page-footer-inner"> &copy; 2020 - <?php echo date("Y"); ?> VPN BY FastSurfingVPN reworked with <i class="fa fa-heart heartbeat animate-infinite-heartbeat"></i> by
				<a href="javascript:void(0);" target="_top" class="makerCss">Dark Cry</a>
			</div>
			<div class="scroll-to-top">
				<i class="icon-arrow-up"></i>
			</div>
		</div>
		<!-- end footer -->
</div>
</body>
</html>
<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">List of Servers Available</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Server List</li>
							</ol>
						</div>
					</div>

    <!-- Main content -->
    <section class="content">
    <div class="row">
	        <?php if ($message): ?>     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i><?php echo $message['type']; ?></h4>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
        <?php foreach (($servers?:array()) as $server): ?>
        
 <div class="col-sm-6 col-md-4 col-lg-3">
      <div class="card-box">
      <div class="card-head">
      <header><i class="icon fa fa-server"></i> <b><?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( Locked )'; ?></header>
      <!-- /.box-tools -->
        </div><!-- /.box-header -->
        <div class="card-body table-responsive">
                    <table class="table">
                         <tr class="noBorder">                    
			<td>Location</td><td><?php echo $server->country; ?></td>
                  </tr>
                  <tr class="noBorder">
                    <td>Validity</td><td>30 days</td>
                  </tr>
		  <tr class="noBorder">
                    <td>Balance</td><td><?php echo $me->saldo; ?></td>
                   </tr>

                  <tr class="noBorder">
                    <td>Server Owner</td><td><?php echo $server->server_owner; ?></td>
                   </tr>
                    </table>
        </div><!-- /.box-body -->
       
     
        <div class="form-group text-center">                
              <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-primary btn-block">Create</a>             
                 </div><!-- /.box-footer-->
       </div><!-- /.box -->
          </div>
 <?php endforeach; ?>               
                
        </div>        
                              
                

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
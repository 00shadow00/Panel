<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Change Password</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li><a href="/home/member/server">List Server</a>&nbsp;<i class="fa fa-angle-right"></i></li>
								<li class="active">Profile</li></li>
							</ol>
						</div>
					</div>

    <!-- Main content -->
    <section class="content">
      
  <div class="row">     
	        
         <div class="col-lg-6">   
  <div class="card card-box">
		 <div class="card-head">
               <header><i class="icon fa fa-pencil"></i> <b>Note:</b></header>
                
                <ol>
                   <li>Use strong password</li>
                   <li>Username without spaces</li>
                   <li>Username and password can not be the same</li>
                   <li>Be able to follow server rules: <a href="#" target="_blank">Here</a></li>
                </ol>
        </div><!-- /.box-header -->
        
        
   </div><!-- /.box -->
          </div>   <!-- /.col -->
 
            <div class="col-md-6">   
  <div class="card card-box">
   <div class="card-head">
	<header><i class="icon fa fa-server"></i> <b><?php echo $me->username; ?></b></header>
   <!-- /.box-tools -->
        </div><!-- /.box-header -->
        <div class="card-body">
            
            
            <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
            <br>
            
                     <form role="form" action="<?php echo $URI; ?>" method="POST">
                        <div class="form-group">
                            <label>Old Password</label>
                            <input class="form-control" placeholder="Type Old password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="Type New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Type Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>       
      

        <div class="box-footer text-center">                
                        <button class="btn btn-primary">Create</button>
                        <a href="/home/member/server" class="btn btn-default">Back</a>               
        
        
                 </div><!-- /.box-footer-->
                     
    </form>
                 </div><!-- /.box-body -->  
        </div><!-- /.box -->
 
          </div>     <!-- /.col -->   
<br/>
<br/>
</div>
    <br/>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
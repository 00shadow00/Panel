<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								
								<div class="page-title"><a href="<?php echo $URI; ?>/add" class="btn btn-round text-white btn-warning"><i class="fa fa-plus"></i> Add</a>&nbsp;Server List</div>

							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Server List</li>
							</ol>
						</div>
					</div>
					

    <!-- Main content -->
    <section class="content">
    <div class="row">    
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>

        <?php foreach (($servers?:array()) as $server): ?>
        
 <div class="col-md-4 col-sm-6 col-12">
      <div class="card-box">
      <div class="card-head">
      <header><i class="icon fa fa-server"></i> <b><?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( Locked )'; ?></header>
	<!-- /.box-tools -->
        </div><!-- /.box-header -->
        <div class="card-body table-responsive">
                    <table class="table">
                        <tr>
                            <td>Location</td><td><?php echo $server->country; ?></td>
                        </tr>
                        <tr>
                            <td>Host Address</td><td><?php echo $server->host; ?></td>
                        </tr>
                        <tr>
                            <td>Account Creation</td><td><?php echo $server->price; ?></td>
                        </tr>
                    </table>
        </div>
	<!-- /.box-body -->
     
        <div class="form-group text-center">                
                        <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-primary"><i class="fa fa-edit fa-fw"></i>Edit</a>
                        <a href="<?php echo $URI.'/'.$server->id; ?>/account" class="btn btn-danger"><i class="fa fa-group fa-fw"></i>User List</a>                
        
        
                 </div>
	<!-- /.box-footer-->
        </div>
	<!-- /.box -->
          </div>
 <?php endforeach; ?>               
</div>                
                
                              
                

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
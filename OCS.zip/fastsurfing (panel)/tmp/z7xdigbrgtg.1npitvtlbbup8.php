<div class="page-wrapper">
		<!-- start header -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/130527/h5ab-snow-flurry.js"></script>
		<div class="page-header navbar navbar-fixed-top">
			<div class="page-header-inner ">
				<!-- logo start -->
				<div class="page-logo">
					<a href="/">
						<span class="logo-icon material-icons fa-rotate-45">vpn_lock</span>
						<span class="logo-default">FastSurfing</span> </a>
				</div>
				<!-- logo end -->
				<ul class="nav navbar-nav navbar-left in">
					<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
				</ul>
				<!-- start mobile menu -->
				<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse"
					data-target=".navbar-collapse">
					<span></span>
				</a>
				<!-- end mobile menu -->
				<!-- start header menu -->
				<div class="top-menu">
				<ul class="nav navbar-nav pull-right">
				
				<!-- start message dropdown -->
						<li class="dropdown dropdown-extended dropdown-inbox" id="header_inbox_bar">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-close-others="true">
								<i class="fas fa-user-tie"></i>
								<span class="badge headerBadgeColor2"> 1 </span>
							</a>
							<ul class="dropdown-menu">
								<li class="external">
									<h3><span class="bold">Staff List</span></h3>
								</li>
								<li>
									<ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
										<li>
											<a href="#">
												<span class="photo">
													<img src="https://i.postimg.cc/ZKv3D4XK/userimage.png" class="img-circle" alt="">
												</span>
												<span class="subject">
													<span class="from"> <?php echo $me->username; ?> </span>
													<span class="from text-muted">( <?php echo $me->email; ?> )</span>
												</span>
												<span class="message"> <?php echo $me->type==1?'Administrator':'Reseller'; ?> </span>
											</a>
										</li>
										
									</ul>
									<div class="dropdown-menu-footer">
										<a href="#"> Be Part of our Team! </a>
									</div>
								</li>
							</ul>
						</li>
						<!-- end message dropdown -->
						<!-- start manage user dropdown -->
						<li class="dropdown dropdown-user">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-close-others="true">
								<img alt="" class="img-circle " src="https://i.postimg.cc/ZKv3D4XK/userimage.png" />
								<span class="username username-hide-on-mobile"> <?php echo $me->username; ?> </span>
								<i class="fa fa-angle-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-menu-default">
								<li>
									<a href="javascript:;" class="fullscreen-btn"><i class="fa fa-arrows-alt"></i> Full screen</a>
								</li>
								<li>
									<a href="/profile">
										<i class="icon-people"></i> Profile </a>
								</li>
								<li>
									<a href="/logout">
										<i class="icon-logout"></i> Log Out </a>
								</li>
							</ul>
						</li>
						<!-- end manage user dropdown -->
						</ul>
				</div>
			</div>
		</div>
		<!-- end header -->
		<!-- start color quick setting -->
		<div class="quick-setting-main">
			<button class="control-sidebar-btn btn" data-toggle="control-sidebar"><i
					class="fas fa-cog fa-spin"></i></button>
			<div class="quick-setting display-none">
				<ul id="themecolors">
					
					<li>
						<p class="selector-title">Sidebar Color</p>
					</li>
					<li class="complete">
						<div class="theme-color sidebar-theme">
							<a href="#" data-theme="white"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="dark"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="blue"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="indigo"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="cyan"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="green"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="red"><span class="head"></span><span class="cont"></span></a>
						</div>
					</li>
					<li>
						<p class="selector-title">Header Brand color</p>
					</li>
					<li class="theme-option">
						<div class="theme-color logo-theme">
							<a href="#" data-theme="logo-white"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="logo-dark"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="logo-blue"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="logo-indigo"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="logo-cyan"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="logo-green"><span class="head"></span><span class="cont"></span></a>
							<a href="#" data-theme="logo-red"><span class="head"></span><span class="cont"></span></a>
						</div>
					</li>
					<li>
						<p class="selector-title">Header color</p>
					</li>
					<li class="theme-option">
						<div class="theme-color header-theme">
							<a href="#" data-theme="header-white"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-dark"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-blue"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-indigo"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-cyan"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-green"><span class="head"></span><span
									class="cont"></span></a>
							<a href="#" data-theme="header-red"><span class="head"></span><span class="cont"></span></a>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<!-- end color quick setting -->
		<!-- start page container -->
		<div class="page-container">
			<!-- start sidebar menu -->
			<div class="sidebar-container">
				<div class="sidemenu-container navbar-collapse collapse fixed-menu">
					<div id="remove-scroll" class="left-sidemenu">
						<ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false"
							data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
							<li class="sidebar-toggler-wrapper hide">
								<div class="sidebar-toggler">
									<span></span>
								</div>
							</li>
							<li class="sidebar-user-panel">
								<div class="user-panel">
									<div class="pull-left image">
										<img src="https://i.postimg.cc/ZKv3D4XK/userimage.png" class="img-circle user-img-circle"
											alt="User Image" />
									</div>
									<div class="pull-left info">
										<p> <?php echo $me->username; ?></p>
										<a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline">
												Online</span></a>
									</div>
								</div>
							</li>
							

							<li class="nav-item start active open">
								<a href="/" class="nav-link nav-toggle">
									<i class="material-icons">dashboard</i>
									<span class="title">Dashboard</span>
									<span class="selected"></span>
									</a>
							</li>
							<?php if ($me->type==1): ?>
                        				
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle"> <i class="material-icons">dns</i>
									<span class="title">Servers</span> <span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									<li class="nav-item">
										<a href="/home/admin/server" class="nav-link "> <span class="title">Server List</span>
										</a>
									</li>
									<li class="nav-item">
										<a href="/home/admin/server/add" class="nav-link "> <span class="title">Add Server</span>
										</a>
									</li>
								</ul>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle"><i class="material-icons">group</i>
									<span class="title">Sellers</span><span class="arrow"></span></a>
								<ul class="sub-menu">
									<li class="nav-item">
										<a href="/home/admin/seller" class="nav-link "> <span class="title">Seller List</span>
										</a>
									</li>
									<li class="nav-item">
										<a href="/home/admin/seller/add" class="nav-link "> <span class="title">Add
												Seller</span>
										</a>
									</li>
									</ul>
							</li>
							
							<?php else: ?>
							<li class="nav-item">
								<a href="/home/member/server" class="nav-link nav-toggle"> <i class="material-icons">create</i>
									<span class="title">Create Account</span>
								</a>
							</li>
							
							<?php endif; ?>
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle"> <i class="material-icons">get_app</i>
									<span class="title">Downloads</span> <span class="arrow"></span>
									</a>
								<ul class="sub-menu">
							<li><a href="https://itunes.apple.com/us/app/openvpn-connect/id590379981?mt=8"><i class="fab fa-apple"></i> OpenVPN</a></li>
							<li><a href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn"></i><i class="fab fa-android"></i> OpenVPN</a></li>
							<li><a href="https://swupdate.openvpn.org/community/releases/openvpn-install-2.4.6-I602.exe"><i class="fab fa-windows"></i> OpenVPN</a></li>
							<li><a href="http://a-dev1412.github.io/A-Dev1412_HPI_1.0.1.7_Setup.zip"><i class="fab fa-windows"></i> HTTP Injector</a></li>
							<li><a href="https://play.google.com/store/apps/details?id=com.evozi.injector&hl=en"><i class="fab fa-android"></i> HTTP Injector</a></li>
							<li><a href="https://play.google.com/store/apps/details?id=kpn.soft.dev.kpnrevolution"><i class="fab fa-android"></i> KPNTunnel </a></li>
							<li><a href="https://dl.dropbox.com/s/5ki3g5b5x7fy0rx/HTTP%20NET%20HEADER%20V-4.2.exe?dl=2"><i class="fab fa-windows"></i> HTTP Net Header (4.2)</a></li>
								</ul>
							</li>
							<br/>
							
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle"> <i class="material-icons">grade</i>
									<span class="title">Credits</span> <span class="arrow"></span>
								</a>
								<ul class="sub-menu">
									<li class="nav-item">
										<a href="javascript:void(0);" class="nav-link "> <span class="title">Zildjan</span>
										</a>
									</li>
									</ul>
							</li>
							<li class="nav-item">
								<a class="nav-link nav-toggle" data-fancybox data-type="iframe" data-src="//openspeedtest.com/Get-widget.php" href="javascript:;"><i class="material-icons">slow_motion_video</i><span class="title">Speedtest</span></a>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link nav-toggle"> <i class="material-icons">favorite</i>
									<span class="title">Donate</span>
									<span class="label label-rouded label-menu label-danger">new</span>
								</a>
							</li>
							<li class="nav-item">
								<a href="/logout" class="nav-link nav-toggle"> <i class="material-icons">subdirectory_arrow_left</i>
									<span class="title">Logout</span>								
							</a>
							</li>
							</ul>
					</div>
				</div>
<style>
/* customizable snowflake styling */
.snowflake {
  color: #fff;
  font-size: 1em;
  font-family: Arial, sans-serif;
  text-shadow: 0 0 5px #000;
}

@-webkit-keyframes snowflakes-fall{0%{top:-10%}100%{top:100%}}@-webkit-keyframes snowflakes-shake{0%,100%{-webkit-transform:translateX(0);transform:translateX(0)}50%{-webkit-transform:translateX(80px);transform:translateX(80px)}}@keyframes snowflakes-fall{0%{top:-10%}100%{top:100%}}@keyframes snowflakes-shake{0%,100%{transform:translateX(0)}50%{transform:translateX(80px)}}.snowflake{position:fixed;top:-10%;z-index:9999;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:default;-webkit-animation-name:snowflakes-fall,snowflakes-shake;-webkit-animation-duration:10s,3s;-webkit-animation-timing-function:linear,ease-in-out;-webkit-animation-iteration-count:infinite,infinite;-webkit-animation-play-state:running,running;animation-name:snowflakes-fall,snowflakes-shake;animation-duration:10s,3s;animation-timing-function:linear,ease-in-out;animation-iteration-count:infinite,infinite;animation-play-state:running,running}.snowflake:nth-of-type(0){left:1%;-webkit-animation-delay:0s,0s;animation-delay:0s,0s}.snowflake:nth-of-type(1){left:10%;-webkit-animation-delay:1s,1s;animation-delay:1s,1s}.snowflake:nth-of-type(2){left:20%;-webkit-animation-delay:6s,.5s;animation-delay:6s,.5s}.snowflake:nth-of-type(3){left:30%;-webkit-animation-delay:4s,2s;animation-delay:4s,2s}.snowflake:nth-of-type(4){left:40%;-webkit-animation-delay:2s,2s;animation-delay:2s,2s}.snowflake:nth-of-type(5){left:50%;-webkit-animation-delay:8s,3s;animation-delay:8s,3s}.snowflake:nth-of-type(6){left:60%;-webkit-animation-delay:6s,2s;animation-delay:6s,2s}.snowflake:nth-of-type(7){left:70%;-webkit-animation-delay:2.5s,1s;animation-delay:2.5s,1s}.snowflake:nth-of-type(8){left:80%;-webkit-animation-delay:1s,0s;animation-delay:1s,0s}.snowflake:nth-of-type(9){left:90%;-webkit-animation-delay:3s,1.5s;animation-delay:3s,1.5s}.snowflake:nth-of-type(10){left:25%;-webkit-animation-delay:2s,0s;animation-delay:2s,0s}.snowflake:nth-of-type(11){left:65%;-webkit-animation-delay:4s,2.5s;animation-delay:4s,2.5s}
</style>
<div class="snowflakes" aria-hidden="true">
  <div class="snowflake">
  ❅
  </div>
  <div class="snowflake">
  ❆
  </div>
  <div class="snowflake">
  ❅
  </div>
  <div class="snowflake">
  ❆
  </div>
  <div class="snowflake">
  ❅
  </div>
  <div class="snowflake">
  ❆
  </div>
  <div class="snowflake">
    ❅
  </div>
  <div class="snowflake">
    ❆
  </div>
  <div class="snowflake">
    ❅
  </div>
  <div class="snowflake">
    ❆
  </div>
  <div class="snowflake">
    ❅
  </div>
  <div class="snowflake">
    ❆
  </div>
			</div>
			<!-- end sidebar menu -->
<?php echo $this->render($subcontent,$this->mime,get_defined_vars()); ?> 
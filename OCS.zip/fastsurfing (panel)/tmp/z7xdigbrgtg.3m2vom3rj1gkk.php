<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
							<?php if ($seller->id): ?>
  							
								<div class="page-title">Edit Seller</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/">List Seller</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Edit Seller</li>
							</ol>
							
							<?php else: ?>
							<div class="page-title">Add Seller</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item"
										href="/">List Seller</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Add Seller</li>
							</ol>
							
							<?php endif; ?>
						</div>
						</div>
						

    <!-- Main content -->
    <section class="content">
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
			
		<div class="row">
        <div class="col-md-6">	
	 <div class="card card-box">
	 <div class="card-head">
               <header><i class="fa fa-user fa-fw"></i> Seller Account<header>
            </div>
            <!-- /.box-header -->
            <!-- form start -->

            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="card-body">
              			<div class="form-group">
                            <label>Email</label>
                            <input class="form-control" placeholder="Email" name="email" type="text" value="<?php echo $seller->email; ?>" required>
                        </div>
						<div class="form-group">
                            <label>First name</label>
                            <input class="form-control" placeholder="First name" name="firstname" type="text" value="<?php echo $seller->firstname; ?>" required>
                        </div>
						<div class="form-group">
                            <label>Last name</label>
                            <input class="form-control" placeholder="Last name" name="lastname" type="text" value="<?php echo $seller->lastname; ?>" required>
                        </div>
                         <div class="form-group">
                            <label>Username</label>
                            <input class="form-control" placeholder="Username" name="username" type="text" value="<?php echo $seller->username; ?>" required>
                        </div>
                        <?php if (!$seller->id): ?>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" placeholder="New Password" name="password" type="password" required>
                            </div>
                            <div class="form-group">
                                <label>Re-enter Password</label>
                                <input class="form-control" placeholder="Re-enter Password" name="password_confirmation" type="password" required>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Balance</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="100" name="saldo" type="number" step="1" value="<?php echo $seller->saldo; ?>" required>
                            </div>
                        </div>
						
              </div>
              <!-- /.box-body -->

              <div class="form-group">
                <center><button type="submit" class="btn btn-primary">Save</button>
                        <?php if ($seller->id): ?>
                            
                                <?php if ($seller->active==1): ?>
                                    
                                        <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Locked</a>
                                    
                                    <?php else: ?>
                                        <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlocked</a>
                                    
                                <?php endif; ?>
                                <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger">Delete</a>
                            
                            <?php else: ?>
                                <a href="/home/admin/seller" class="btn btn-default">Back</a></center>
                            
                        <?php endif; ?>
				              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>

       <?php if ($seller->id): ?>		  
        <div class="col-md-6">		  
         <div class="card card-box">
	 <div class="card-head">
               <header><i class="fa fa-cog fa-spin"></i> Change Password</header>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="card-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input class="form-control" placeholder="New Password" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>Re-enter New Password</label>
                            <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="form-group text-center">
                <button type="submit" class="btn btn-primary">Save</button>
              <a href="/home/admin/seller" class="btn btn-default">Back</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
<?php endif; ?>
		  
          </div>		  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
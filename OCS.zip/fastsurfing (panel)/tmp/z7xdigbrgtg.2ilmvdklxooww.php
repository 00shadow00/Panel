<div class="page-content-wrapper">
<script type="application/javascript">
  function getIP(json) {
    document.write("", json.ip);
  }
</script>




				<div class="page-content">
					<div class="page-bar">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Dashboard</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
										href="/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">Dashboard</li>
							</ol>
						</div>
					</div>
					<!-- start widget -->
					<div class="state-overview">
						<div class="row">
							<div class="col-xl-3 col-md-6 col-12">
								<div class="info-box bg-b-green">
									<span class="info-box-icon push-bottom"><i class="material-icons">people</i></span>
									<div class="info-box-content">
										<span class="info-box-text">User Type</span>
										<span class="info-box-number"><?php echo $me->type==1?'VIP':'Premium'; ?></span>
										</div>
									
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
							<div class="col-xl-3 col-md-6 col-12">
								<div class="info-box bg-b-yellow">
									<span class="info-box-icon push-bottom"><i class="material-icons">router</i></span>
									<div class="info-box-content">
										<span class="info-box-text">Current IP Address</span>
										<span class="info-box-number"><script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script></span>
										</div>
										
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
							<div class="col-xl-3 col-md-6 col-12">
								<div class="info-box bg-b-blue">
									<span class="info-box-icon push-bottom"><i class="material-icons">dns</i></span>
									<div class="info-box-content">
										<span class="info-box-text">Server Status</span>
										<span class="info-box-number counting" data-count="100">0</span> %
										</div>
										
									<!-- /.info-box-content -->
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
							<div class="col-xl-3 col-md-6 col-12">
								<div class="info-box bg-b-pink">
									<span class="info-box-icon push-bottom"><i
											class="material-icons">shopping_cart</i></span>
									<div class="info-box-content">
										<span class="info-box-text">Balance</span>
										<span class="info-box-number"><?php echo $me->saldo; ?></span>										</div>
									<!-- /.info-box-content -->
								
								</div>
								<!-- /.info-box -->
							</div>
							<!-- /.col -->
						</div>
					</div>
					<!-- end widget -->
						<div class="row">
            					
					<div class="col-lg-6 col-md-12 col-sm-12 col-12">
							<div class="card  card-box">
								<div class="card-head">
									<header>Announcement</header>
									<div class="tools">
										<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
									</div>
								</div>
								<div class="card-body no-padding height-9">
									<div class="row">
										<div class="noti-information notification-menu">
											<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto;"><div class="notification-list mail-list not-list small-slimscroll-style" style="overflow: hidden; width: auto;">
												<a href="javascript:;" class="single-mail"> <span class="icon bg-primary"> <i class="far fa-clock"></i>
													</span><strong>Server Reboot Time</strong>
													<span class="notificationtime">
													04:00 AM GMT +8 PH Standard time.
													</span>
												</a>
												<a href="javascript:;" class="single-mail"> <span class="icon bg-danger"> <i class="fa fa-warning"></i>
													</span><strong>Warning</strong>													
													<span class="notificationtime">
														Please follow the rules carefully to avoid account blocking.
													</span>
												</a>
												<a href="javascript:;" class="single-mail"> <span class="icon bg-success"> <i class="fas fa-shield-alt"></i>
													</span> <strong>Protection</strong>
													<span class="notificationtime">
														All servers are protected with Anti Torrent.
													</span>
												</a>
												<a href="javascript:;" class="single-mail"> <span class="icon bg-warning"> <i class="fas fa-exclamation-circle"></i>
													</span> <strong>Registration Issue</strong>
													<span class="notificationtime">
														Use strong username or password when creating an account by adding numbers.
													</span>
												</a>
												</div><div class="slimScrollBar" style="background: rgb(158, 165, 171); width: 5px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 200px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
											<div class="full-width text-center p-t-10">
												</div>
										</div>
									</div>
								</div>
							</div>
						</div>

<div class="col-lg-6 col-md-12 col-sm-12 col-12">
							<div class="card  card-box">
								<div class="card-head">
									<header>News</header>
									<div class="tools">
										<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
									</div>
								</div>
								<div class="card-body ">
									<div class="row">
										<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto;"><ul class="docListWindow small-slimscroll-style" style="overflow: hidden; width: auto;">
											<li>
												<div class="prog-avatar">
													<img src="/assets/img/bootstrap.png" alt="" width="40" height="40">
												</div>
												<div class="details">
													<div class="title">
														Simple Dark Themed Dashboard
													</div>
													<div>
														<span>Responsive and user friendly UI powered by Bootstrap.</span>
													</div>
												</div>
											</li>
											<li>
												<div class="prog-avatar">
													<img src="/assets/img/messenger.png" alt="" width="40" height="40">
												</div>
												<div class="details">
													<div class="title">
														Chat Support
													</div>
													<div>
														<span>Support system added using Facebook Messenger Plugin.</span>
													</div>
												</div>
											</li>
											<li>
												<div class="prog-avatar">
													<img src="/assets/img/gcashglobe.png" alt="" width="40" height="40">
												</div>
												<div class="details">
													<div class="title">
														Donation
													</div>
													<div>
														<span>I am now accepting donation through <a target="_blank" rel="noopener noreferrer" href="https://www.gcash.com/">GCash</a>.</span>
													</div>
												</div>
											</li>
											<li>
												<div class="prog-avatar">
													<img src="/assets/img/speed.jpg" alt="" width="40" height="40">
												</div>
												<div class="details">
													<div class="title">
														Speed Test
													</div>
													<div>
														<span>Test your internet speed using <a data-fancybox data-type="iframe" data-src="//openspeedtest.com/Get-widget.php" href="javascript:;"><span>Open Speed test</span></a>.</span>
													</div>
												</div>
											</li>
											</ul><div class="slimScrollBar" style="background: rgb(158, 165, 171); width: 5px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 285.34px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
										<div class="full-width text-center p-t-10">
											</div>
									</div>
								</div>
							</div>
						</div>
				</div>

	</div>
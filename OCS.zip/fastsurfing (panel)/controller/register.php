<?php

class Register extends Controller {

	function Ins($f3) {
		if ($f3->exists('SESSION.id')) $f3->reroute('/register');
		$f3->set('content','register.html');
	}

	function Reg($f3) {
		$name = $f3->get('POST.username');
		$pass = $f3->get('POST.password');
		$email = $f3->get('POST.email');
		$user = new \User;
		$user->load(array('username=?',$name));
		if ( ! $user->dry()) {
			$this->flash('Username already used!');
		}else{
		
    		$user->username = $name;
    		$user->password = $pass;
    		$user->email = $email;
    		$user->save();
    		$this->flash('Successfully registered! Please login!', 'info');
    		$f3->reroute('/');
		}
		
		$this->flash('Username already used!!');
		$f3->reroute('/register');
	}

	function Out($f3) {
		$f3->clear('SESSION');
		$f3->reroute('/register');
	}

}